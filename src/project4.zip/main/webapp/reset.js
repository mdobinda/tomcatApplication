function reset() {
    document.getElementById('textBox').value = " ";
}